=====
Usage
=====

To use sentiment-timeseries in a project::

    import sentiment_timeseries
