def say_hello(name='stranger'):
    print(f"Hello {name}")